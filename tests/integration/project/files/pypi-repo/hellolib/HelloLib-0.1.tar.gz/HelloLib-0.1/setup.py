from setuptools import setup

setup(
    name='HelloLib',
    version='0.1',
    description='Python Library that provides hello() method',
    packages=['hellolib'],
)
