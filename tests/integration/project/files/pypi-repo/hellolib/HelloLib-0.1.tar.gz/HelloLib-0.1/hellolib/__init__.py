def hello(actor='world'):
    print('Hello {}!'.format(actor))
