from setuptools import setup

setup(
    name='App2',
    version='0.1',
    description='App2',
    packages=['app2'],
    entry_points={
        'console_scripts': [
            'app2=app2:main'
        ]
    }
)
