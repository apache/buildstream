def main():
    print('Hello World! This is App2')
