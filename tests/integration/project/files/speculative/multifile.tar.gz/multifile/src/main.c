#include <config.h>
#include <stdio.h>
#include "common.h"
#include <dep.h>
int main(void) {
    printf("app: dep_version=%d\n", DEP_VERSION);
    util_func();
    return 0;
}
