#ifndef COMMON_H
#define COMMON_H
void util_func(void);
#endif
