#include <stdio.h>
#include "common.h"
void util_func(void) {
    printf("util: stable across dep changes\n");
}
