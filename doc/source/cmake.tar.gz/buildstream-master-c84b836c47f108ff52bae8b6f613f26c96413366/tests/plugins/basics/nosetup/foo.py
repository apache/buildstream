# A plugin is supposed to define a setup function
# which returns the type that the plugin provides
#
# This plugin fails to do so


def useless():
    print("Hello World")
