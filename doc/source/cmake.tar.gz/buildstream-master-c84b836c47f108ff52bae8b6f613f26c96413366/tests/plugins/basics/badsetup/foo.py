# A plugin is supposed to define a setup function
# which returns the type that the plugin provides
#
# This plugin provides a setup() symbol that is
# not even a function
setup = 5
