from buildstream import Element


class AnotherFooElement(Element):
    pass


def setup():
    return AnotherFooElement
