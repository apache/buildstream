# Plugins are supposed to return a subclass type
# of Source or Element, depending on plugin type.


def setup():
    return 5
