from buildstream import Element


class FrobElement(Element):
    pass


def setup():
    return FrobElement
