from buildstream import Element


class FooElement(Element):
    pass


def setup():
    return FooElement
