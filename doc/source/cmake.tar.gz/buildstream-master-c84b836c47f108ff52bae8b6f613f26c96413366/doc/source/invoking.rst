.. _invoking:

Invoking BuildStream
====================

.. click:: buildstream._frontend.main:cli
   :prog: bst
   :show-nested:
